
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */




public class databaseconnection {
    static Connection connection(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmanagement", "root", "");
            return con;
        }catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found. Include the JDBC jar in your project.");
            e.printStackTrace();
            return null;
        } catch (SQLException e) {
            System.out.println("Connection failed! Check output console");
            e.printStackTrace();
           
        }
        return null;
    }
}
        
    
            
